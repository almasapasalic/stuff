package com.qa.selenium.webdriverStuff;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DemoSiteDDT {
	
	FileInputStream file = null; {
	try { 
		file = new FileInputStream(Constant.Path_TestData +
				Constant.File_TestData);
	}
	catch (FileNotFoundException e) {}
	XSSFWorkbook workbook = null;
	try { 
		workbook = new XSSFWorkbook("C:\\Users\\Admin\\Desktop\\DemoSiteDDT.xlsx");
	}
	catch (IOException e) {} 
	XSSFSheet sheet = workbook.getSheetAt(0);
	XSSFCell cell = sheet.getRow(0).getCell(0);
	System.out.println(cell.getStringCellValue());
	
	}
}
