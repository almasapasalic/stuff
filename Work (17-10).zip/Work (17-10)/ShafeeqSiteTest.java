package com.qa.selenium.webdriverStuff;

import static org.junit.Assert.assertEquals;
import org.junit.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.*;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class ShafeeqSiteTest {
	
	boolean replaceExisting;
	WebDriver driver;
	ShafeeqSite page;
	
	/* REPORT */ 
	
	// initialise
	ExtentReports extent = new ExtentReports ("C:\\Users\\Admin\\Desktop\\Almasa Pasalic\\ShafeeqReport.html", replaceExisting);
	ExtentTest test; {
	
	// start test 
	test = extent.startTest("Wait for dynamic element");
	
	// add note 
	test.log(LogStatus.INFO, "Browser started");
	
	// report test as pass 
	test.log(LogStatus.PASS, "Dynamic element appeared");
	
	}
	
	@Before
	public void setup() { 
		System.setProperty("webdriver.chrome.driver", 
		"C:\\Users\\Admin\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver(); 
	}
	
	@After
	public void teardown() { 
		driver.quit();
		extent.flush();
	}
	
	@Test 
	public void hateSite() throws InterruptedException { 
		
		ShafeeqSite page = PageFactory.initElements(driver, ShafeeqSite.class);
		driver.manage().window().maximize();
		driver.get(ShafeeqSite.url);
		
		
		assertEquals("error", "I HATE YOU!\n-The Shafeeq", page.Wait(driver).getText()); 
	}
}