package com.qa.selenium.webdriverStuff;

import org.junit.*;
import org.openqa.selenium.chrome.ChromeDriver;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class ShoppingWebsite {
	
	ChromeDriver driver; 
	
	@Before 
	public void setup() { 
		System.setProperty("webdriver.chrome.driver",
		"C:\\Users\\Admin\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver(); 
	}
	
	@After
	public void teardown() { 
		//driver.quit();
	}
	
	@Test
	public void searchItem() { 
		f
	}
	

}
