package com.qa.Assessment;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "C:\\Users\\Admin\\eclipse-workspace\\Assessment\\src\\main\\java\\com\\qa\\Assessment\\FridayAssessment (no Email Box).feature")

public class TaskOneRunner {
	
	
}
